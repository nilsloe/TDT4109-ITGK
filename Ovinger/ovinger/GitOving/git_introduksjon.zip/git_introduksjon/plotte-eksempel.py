#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Jul 20 16:44:41 2020

@author: user
"""
import matplotlib.pyplot as plt
import numpy as np

x = np.linspace(0,10,50)
y = np.sin(x)

plt.plot(x,y)