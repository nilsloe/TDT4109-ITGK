#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Jul 20 16:51:31 2020

@author: user
"""

print("Nytt Python dokument.")